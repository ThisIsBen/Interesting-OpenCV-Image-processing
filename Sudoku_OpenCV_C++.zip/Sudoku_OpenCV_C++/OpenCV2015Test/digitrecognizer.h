#pragma once
#include <opencv/highgui.h>
#include <opencv/cv.h>
#include <opencv/ml.h>

using namespace cv;
using namespace std;
#define MAX_NUM_IMAGES    60000
class DigitRecognizer
{
public:
	DigitRecognizer();

	~DigitRecognizer();

	bool train(char* trainPath, char* labelsPath);

	//takens an image and returns what digit it is
	int classify(Mat img);

private:
	//do some preprocessing.
	Mat preprocessImage(Mat img);

	//has something to do with the endiannesss of your processor and the file-format of the dataset we're using.
	int readFlippedInteger(FILE *fp);

private:

	//knn is a k-Nearest Neighbor data structure... and numRows, numCols and numImages stores the number of rows and columns in the training dataset. numImages stores the number of images in the dataset.
	KNearest    *knn; //��tutorial
	//Ptr<ml::KNearest> knn;
	int numRows, numCols, numImages;

};